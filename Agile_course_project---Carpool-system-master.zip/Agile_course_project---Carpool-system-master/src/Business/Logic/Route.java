package Business.Logic;

public class Route {

    private Location source;
    private Location destination;

}
