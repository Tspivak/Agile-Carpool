package Hitchhiker.side;

/**
 * Hitchhiker.side.NoCarAssignedException
 */
public class NoCarAssignedException extends Exception{

	private static final long serialVersionUID = 1L;

    public NoCarAssignedException(String msg) {
        super(msg);
    }
}