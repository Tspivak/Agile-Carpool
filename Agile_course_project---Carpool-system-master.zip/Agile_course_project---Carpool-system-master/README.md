# Agile_course_project---Hitchhiker.side.Carpool-system
As a part of an Academic class on Agile software dev methodologies - a project dedicated to the development of a carpool system
